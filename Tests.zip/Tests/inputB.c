int main(){
    
    /* This is sample test File */

    // declarations
    int x;
    int a[4];
    bool y;
    bool y[10];

    // statements 
    foo[2] = (foo[3] + (foo[4] * foo[5]));
    num = num + (num * f4o[4/2] + num * (num * dFg));
    foo[true / false] = true + true % false;
    x[10 / y[10] + (4 + (5 * fg[10]))] = 4 * (5 + 12 * df[10 / 0]) + gh[((10 + 1) * (gh[10 / fg[10] + 19 ])) % MOD]; 
    
}
